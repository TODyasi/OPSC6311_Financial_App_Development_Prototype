package com.example.opsc_6311_poe_prototype_v2

data class Expenses(val categoryName: String, val expenseAmount: Double){
}