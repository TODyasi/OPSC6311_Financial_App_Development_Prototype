package com.example.opsc_6311_poe_prototype_v2

data class Catagories(val categoryName : String) {
}