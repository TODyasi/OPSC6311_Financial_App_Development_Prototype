package com.example.opsc_6311_poe_prototype_v2

data class Budget(val balance:Double = 0.0) {
}