package com.example.opsc_6311_poe_prototype_v2

data class User(val firstName: String="",
                val lastName: String="",
                val password: String="",
                val userName: String="",
                val email: String="") {

}